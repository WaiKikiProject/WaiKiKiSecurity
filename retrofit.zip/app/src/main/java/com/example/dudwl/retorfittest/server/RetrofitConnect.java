package com.example.dudwl.retorfittest.server;

import com.example.dudwl.retorfittest.Vo.User;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by dudwl on 2018-03-24.
 */

public class RetrofitConnect {
    public static final String baseUrl = "https://api.hospitality-staging.imgate.co.kr/v2/";

    private ServiceInterface getService() {
        Retrofit retrofit = new Retrofit.Builder().baseUrl(baseUrl).addConverterFactory(GsonConverterFactory.create()).build();
        ServiceInterface service = retrofit.create(ServiceInterface.class);

        return service;
    }

    public Call loginConnec(String email,String password){
        User user = new User();
        user.setEmail(email);
        user.setPassword(password);
        Call<User> call = getService().login(user);
        return call;
    }

    ;
}
