package com.example.dudwl.retorfittest.server;

import com.example.dudwl.retorfittest.Vo.User;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by dudwl on 2018-03-24.
 */

public interface ServiceInterface {

    @POST("staffs/session/")
    Call<User> login(@Body User user);
}
