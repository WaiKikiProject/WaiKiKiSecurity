/**
 * http://usejsdoc.org/
 */

exports.create = function(install_code,connection,callback){
	
	console.log("start CreateEventAPI");
	
	var result_code = require("../conf/ResultCode");
	var async = require('async');

	async.series({
		
		checkParameter : function(asyncCallback){		
			console.log("start checkParameter");
			if(install_code == null){
				console.log("MissmatchParameter");
				callback.resultcallback(result_code.MissMatchParameterMessage,result_code.MissMatchParameterCode);
				asyncCallback(true);
			}else{
				asyncCallback(null);
			}
		},

		  insertEvent: function(asyncCallback){
			
			  console.log("Start InsertQuery");
			
			  var date = new Date();
			  var insertstmt = "insert into event values(?,now(),?)";
			  connection.query(insertstmt, [date.getTime().toString(),install_code], function(err, result) {
				  if(err){
					connection.rollback(function () {
						callback.resultcallback(result_code.DatabaseErrorMessage,result_code.DatabaseErrorCode);
						asyncCallback(true);
                     });
				  }else{
					  
					 console.log("Start InsertQuery2");
					  
					 var insertstmt2 = "insert into confirmevent values(?,?,'x')";
					  connection.query(insertstmt2, [date.getTime().toString(),install_code], function(err, result) {
						  if(err){
							  connection.rollback(function () {
								  	callback.resultcallback(result_code.DatabaseErrorMessage,result_code.DatabaseErrorCode);
									asyncCallback(true);
			                     });
						  }else{
							asyncCallback(null);
						  }
					  });
				  }
			  });
		  }
		  
	},
	
	asyncCallback = function(err){
		
		 if (err)
		        console.log('err');
		 else
		        console.log('done');
	}
	);

}